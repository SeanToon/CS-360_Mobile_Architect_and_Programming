package com.zybooks.sayhelloapptwoseantoon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //declarations
    TextView textGreeting;
    Button buttonSayHello;
    EditText nameText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //link declared views to layout views
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        //button is initially set to false because not enabled
        buttonSayHello.setEnabled(false);

        //monitor text changes in nameText
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public  void onTextChanged(CharSequence s, int start, int before, int count) {
                buttonSayHello.setEnabled(s.length() > 0);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        //set OnClickListener for buttonSayHello
        buttonSayHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sayHello(view);
            }
        });
    }

    // greeting display method
    private void sayHello(View view) {
        String name = nameText.getText().toString();

        if(!name.isEmpty()) {
            textGreeting.setText("Greetings, " + name);
        }else{
            textGreeting.setText("A name was not entered, please enter a name");
        }
    }
}