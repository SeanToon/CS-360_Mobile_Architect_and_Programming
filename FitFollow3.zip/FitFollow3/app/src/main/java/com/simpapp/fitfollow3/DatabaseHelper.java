package com.simpapp.fitfollow3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    //table and column names
    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_USER_DATE = "USER_DATE";
    public static final String COLUMN_USER_WEIGHT = "USER_WEIGHT";
    public static final String COLUMN_ID = "ID";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "weight_log.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //creating the table with columns
        String createTableStatement = "CREATE TABLE " + WEIGHT_TABLE + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_DATE + " TEXT, " +
                COLUMN_USER_WEIGHT + " INTEGER)";
        db.execSQL(createTableStatement);
    }

    @Override
    //upgrade the database when needed
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    }

    // add weight and date entry to the database table
    public boolean addOne(UserModel userModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        //set content values
        cv.put(COLUMN_USER_DATE, userModel.getDate());
        cv.put(COLUMN_USER_WEIGHT, userModel.getWeight());

        //inserting rows into the table
        long insert = db.insert(WEIGHT_TABLE, null, cv);

        //check to see if insertion was successful
        return insert != -1;
    }

    public boolean updateOne(UserModel userModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        // update content values
        cv.put(COLUMN_USER_DATE, userModel.getDate());
        cv.put(COLUMN_USER_WEIGHT, userModel.getWeight());

        // selection criteria
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(userModel.getId()) };

        // update operation
        int updatedRows = db.update(WEIGHT_TABLE, cv, selection, selectionArgs);
        db.close();

        //check to see if insertion was successful
        return updatedRows > 0;
    }

    //remove entry from the database
    public boolean removeOne(String date, int weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COLUMN_USER_DATE + "=? AND " + COLUMN_USER_WEIGHT + "=?";
        String[] selectionArgs = { date, String.valueOf(weight) };

        //delete specified row of table
        int deletedRows = db.delete(WEIGHT_TABLE, selection, selectionArgs);
        db.close();

        //check if insertion was successful
        return deletedRows > 0;
    }


    //return all entries from the table
    public List<UserModel> getEveryone() {
        List<UserModel> returnList = new ArrayList<>();

        //query to retrieve all data from the table
        String queryString = "SELECT * FROM " + WEIGHT_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            do {
                //using cursor to retrieve values and then creating userModel objects
                int idNum = cursor.getInt(0);
                String userDate = cursor.getString(1);
                int userWeight = cursor.getInt(2);

                UserModel newEntry = new UserModel(idNum, userDate, userWeight);
                returnList.add(newEntry);

            } while (cursor.moveToNext());
        }
        else {

        }
        cursor.close();
        db.close();
        //return list of userModel objects
        return returnList;
    }

}