package com.simpapp.fitfollow3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDB extends SQLiteOpenHelper {
    public static final String DBNAME = "Login.db";

    // constructor
    public LoginDB(Context context) {
        super(context, "Login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        //create 'users' table with columns 'username' and 'password'
        MyDB.execSQL("create Table users(username Text primary key, password TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        //drop 'users' table if it exists on database upgrade
        MyDB.execSQL("drop Table if exists users");
    }

    public boolean insertData(String username, String password){

        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        //insert credentials
        long result = MyDB.insert("users", null, contentValues);
        if(result == -1)
            //if fails
            return false;
        else
            //if successful
            return true;
    }

    // check if username exists in the 'users' table
    public Boolean checkusername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            //if so return true
            return true;
        else
            //else return false
            return false;
    }

    //check if username and password match in the 'users'table
    public Boolean checkusernamepassword(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[]{username, password});
        if (cursor.getCount() > 0)
            //if so, return true
            return true;
        else
            //if not, return false
            return false;
    }

}
