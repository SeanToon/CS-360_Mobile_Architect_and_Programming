package com.simpapp.fitfollow3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SMS extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notify);
    }
}