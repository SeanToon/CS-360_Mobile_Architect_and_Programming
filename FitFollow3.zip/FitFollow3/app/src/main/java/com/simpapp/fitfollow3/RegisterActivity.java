package com.simpapp.fitfollow3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity {

    //ui elements
    EditText newUsernameEditText, newPasswordEditText;
    Button register, login;
    LoginDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // initialize ui elements from layout
        newUsernameEditText = findViewById(R.id.username1);
        newPasswordEditText = findViewById(R.id.password1);
        register = findViewById(R.id.register);
        login = findViewById(R.id.login1);
        DB = new LoginDB(this);

        // register button listener
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get username and password for edittext fields
                String newUsername = newUsernameEditText.getText().toString();
                String newPassword = newPasswordEditText.getText().toString();

                //check if username exists
                Boolean checkuser = DB.checkusername(newUsername);
                //if not insert the new data
                if(checkuser==false){
                    Boolean insert = DB.insertData(newUsername, newPassword);
                    //show success message and navigate to main activity
                    if(insert==true){
                        Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                    //if registration fails
                    }else {
                        Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                //if true, show message that username already exists
                }
                else{
                    Toast.makeText(RegisterActivity.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //login button listener
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //navigate to login activity on click
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
