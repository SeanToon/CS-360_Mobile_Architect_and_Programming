package com.simpapp.fitfollow3;


import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //ui elements
    ListView log;
    EditText editDate, editWeight, goalWeightEditText ;
    Button addButton, deleteButton, updateButton, smsButton;

    //arrayadapter for list view
    ArrayAdapter<UserModel> userArrayAdapter;

    //DB instance and list of usermodel
    DatabaseHelper database;
    List<UserModel> everyone;
    UserModel selectedUser;

    //initial value
    private int goalWeight = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize ui elements from layout
        log = findViewById(R.id.weightList);
        smsButton = findViewById(R.id.smsButton);
        addButton = findViewById(R.id.recordButton);
        deleteButton = findViewById(R.id.deleteButton);
        updateButton = findViewById(R.id.updateButton);
        editDate = findViewById(R.id.addDate);
        editWeight = findViewById(R.id.addWeight);
        goalWeightEditText = findViewById(R.id.goalWeight);


        //initialize database helper/ retrieve data
        database = new DatabaseHelper(MainActivity.this);
        everyone = database.getEveryone();

        //initialize arrayadapter for list view
        userArrayAdapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_1, everyone);
        log.setAdapter(userArrayAdapter);

        //listview item click listener
        log.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                selectedUser = (UserModel) adapterView.getItemAtPosition(position);
                editDate.setText(selectedUser.getDate());
                editWeight.setText(String.valueOf(selectedUser.getWeight()));
            }
        });

        //listener for goal weight input
        goalWeightEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        goalWeight = Integer.parseInt(goalWeightEditText.getText().toString());
                    } catch (NumberFormatException e) {
                        goalWeight = -1; // Set a default value if the input is invalid
                    }
                }
            }
        });

        //update button listener
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //update the selected entry and check for any valid/invalid entries
                if (selectedUser != null) {
                    String newDate = editDate.getText().toString();
                    int newWeight;

                    try {
                        newWeight = Integer.parseInt(editWeight.getText().toString());
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    selectedUser.setDate(newDate);
                    selectedUser.setWeight(newWeight);

                    boolean success = database.updateOne(selectedUser);
                    if (success) {
                        userArrayAdapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Entry updated successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to update entry", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please select an item to update", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // add button listener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // add a new entry and check for any invalid inputs
                String date = editDate.getText().toString();
                int weight;

                try {
                    weight = Integer.parseInt(editWeight.getText().toString());
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                    return; // Exit the onClick method if weight is not valid
                }

                if (goalWeight != -1 && weight == goalWeight) {
                    // notify weight matches the goal weight
                    Toast.makeText(MainActivity.this, "You have reached your goal weight! CONGRADULATIONS!!", Toast.LENGTH_SHORT).show();
                } else {
                    UserModel newUser = new UserModel(-1, date, weight);
                    boolean success = database.addOne(newUser);
                    if (success) {
                        Toast.makeText(MainActivity.this, "Entry added successfully", Toast.LENGTH_SHORT).show();
                        editDate.setText("");
                        editWeight.setText("");
                        everyone.add(newUser);
                        userArrayAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to add entry", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //delete button listener
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //delete selected entry and handle any failed operation
                if (selectedUser != null) {
                    boolean success = database.removeOne(selectedUser.getDate(), selectedUser.getWeight());
                    if (success) {
                        Toast.makeText(MainActivity.this, "Entry deleted successfully", Toast.LENGTH_SHORT).show();
                        everyone.remove(selectedUser);
                        userArrayAdapter.notifyDataSetChanged();
                        selectedUser = null; // Reset selectedUser after deletion
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please select an item to delete", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // SMS button listener
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //navigate to SMS activity
                Intent intent = new Intent(getApplication(), SMS.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "SMS button", Toast.LENGTH_SHORT).show();
            }
        });
    }
}